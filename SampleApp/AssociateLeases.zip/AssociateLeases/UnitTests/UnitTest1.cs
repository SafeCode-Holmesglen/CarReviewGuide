﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using SharedModels;

namespace UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        /// <summary>
        /// Test to see if at least 1 record is returned for employer 1 from the eligibility table.
        /// </summary>
        [TestMethod]
        public void Test_GetEmployeesByEmployer()
        {
            Services.Eligibility servEligibility = new Services.Eligibility();
            List<jsonEligibility> retList = servEligibility.GetEmployeesByEmployer(1);
            Assert.IsTrue(retList.Count > 0);
        }

        [TestMethod]
        public void Test_GetPagedEmployeesByEmployer()
        {
            Services.Eligibility servEligibility = new Services.Eligibility();
            List<jsonEligibility> retList = servEligibility.GetPagedEmployeesByEmployer(1, 1, 10);
            Assert.IsTrue(retList.Count == 10);
        }
    }
}
