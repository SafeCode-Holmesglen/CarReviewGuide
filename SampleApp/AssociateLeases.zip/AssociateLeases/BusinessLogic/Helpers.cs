﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public static class Helpers
    {
        /// <summary>
        /// Returns a pages list of items.
        /// </summary>
        /// <param name="pagedList">The List to page.</param>
        /// <param name="page">The current page number.</param>
        /// <param name="itemCount">Number of items to return in the list.</param>
        /// <returns>List of itemCount items in the list.</returns>
        public static List<T> PageResults<T>(this List<T> pagedList, int page, int itemCount)
        {
            if (page <= 0) page = 1;
            return pagedList.Skip((page - 1) * itemCount).Take(itemCount).ToList();
        }
    }
}
