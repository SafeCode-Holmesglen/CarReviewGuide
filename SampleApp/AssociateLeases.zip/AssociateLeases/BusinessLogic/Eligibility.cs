﻿
using AutoMapper;
using DataAccess;
using DataAccessEDMX;
using SharedModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLogic
{
    public class Eligibility
    {
        /// <summary>
        /// Calls the DAL to get a list of tblEligibility records then converts them to jsonEligibility and returns the shared model list.
        /// </summary>
        /// <param name="employerId">The unique id for the employer.</param>
        /// <returns>List of type jsonEligibility.</returns>
        public List<jsonEligibility> GetEmployeesByEmployer(int employerId)
        {
            Mapper.Initialize(cfg => cfg.CreateMap<tblEligibility, jsonEligibility>());
            
            DataAccess.Repository.Eligibility dalEligibility = new DataAccess.Repository.Eligibility();
            List<tblEligibility> dalList = dalEligibility.GetEligibilityListByEmployer(employerId);

            List<jsonEligibility> retList = Mapper.Map<List<tblEligibility>, List<jsonEligibility>>(dalList);
            
            return retList;
        }

        /// <summary>
        /// Gets a paged list of employees for an employer.
        /// </summary>
        /// <param name="employerId">The unique id of the employer.</param>
        /// <param name="page">1 based page number.</param>
        /// <param name="itemCount">Number of rows to return in the list.</param>
        /// <returns>List of type jsonEligibility.</returns>
        public List<jsonEligibility> GetPagedEmployeesByEmployer(int employerId, int page, int itemCount)
        {
            List<jsonEligibility> retList = GetEmployeesByEmployer(employerId);
            return retList.PageResults(page, itemCount);
        }
    }
}
