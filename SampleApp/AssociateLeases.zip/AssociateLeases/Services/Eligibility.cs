﻿using SharedModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class Eligibility
    {
        /// <summary>
        /// Return a shared model of employees within the eligibility table for a particular employer.
        /// </summary>
        /// <param name="employerId">The unique id for the employer.</param>
        /// <returns>List of type jsonEligibility</returns>
        public List<jsonEligibility> GetEmployeesByEmployer(int employerId)
        {
            List<jsonEligibility> retList = new List<jsonEligibility>();

            BusinessLogic.Eligibility eligibility = new BusinessLogic.Eligibility();
            retList = eligibility.GetEmployeesByEmployer(employerId);

            return retList;
        }

        public List<jsonEligibility> GetPagedEmployeesByEmployer(int employerId, int page, int itemCount)
        {
            List<jsonEligibility> retList = new List<jsonEligibility>();

            BusinessLogic.Eligibility eligibility = new BusinessLogic.Eligibility();
            retList = eligibility.GetPagedEmployeesByEmployer(employerId, page, itemCount);

            return retList;
        }

    }
}
