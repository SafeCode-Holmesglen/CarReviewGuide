﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharedModels
{
    /// <summary>
    /// This is a firect copy of the tblEligibility model but because we never want to send 
    /// a database model to the UI, the DB model is converted into this model.
    /// It's preceded with json as all models passed to the views will be passed as json data.
    /// </summary>
    public class jsonEligibility
    {
        public int id { get; set; }
        public string EmployeeId { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PayCycleId { get; set; }
        public int EmployerId { get; set;}
    }
}
