﻿using DataAccessEDMX;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataAccess.Repository
{
    public class Eligibility
    {
        /// <summary>
        /// Return a list of eligibility records for an employer.
        /// </summary>
        /// <param name="employerId">The unique id for the employer.</param>
        /// <returns>List of type tblEligibility</returns>
        public List<tblEligibility> GetEligibilityListByEmployer(int employerId)
        {
            List<tblEligibility> retList;

            try
            {
                using (var context = new ModelContainer())
                {
                    retList = context.tblEligibilities.Where(x => x.EmployerId == employerId).OrderBy(x => x.LastName).ThenBy(x => x.FirstName).ToList();
                }
            } catch (Exception ex) {
                // logging should be done here.
                return null;
            }

            return retList;
        }
    }
}
