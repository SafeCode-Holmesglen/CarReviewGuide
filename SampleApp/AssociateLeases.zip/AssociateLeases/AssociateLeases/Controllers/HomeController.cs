﻿using AssociateLeases.ViewModels;
using SharedModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AssociateLeases.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            Services.Eligibility servEligibility = new Services.Eligibility();
            List<jsonEligibility> retList = servEligibility.GetPagedEmployeesByEmployer(1, 1, 10);
            vmHomeIndex viewModel = new vmHomeIndex { employerEligibilityList = retList };

            return View(viewModel);
        }

        public ActionResult GetNextPage(int page, int itemCount)
        {
            Services.Eligibility servEligibility = new Services.Eligibility();
            List<jsonEligibility> retList = servEligibility.GetPagedEmployeesByEmployer(1, page, itemCount);

            return PartialView("EligibilityList", retList);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}