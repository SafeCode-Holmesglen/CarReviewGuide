﻿pagingControlObj = function () {
    this.currentPage = 1;
    this.itemCount = 10;
}
var pagingControl = new pagingControlObj();

$(function () {
    $("body").on("click", "#pageFirst", function () {
        pagingControl.currentPage = 1;
        LoadPageResults();
    });

    $("body").on("click", "#pageNext", function () {
        pagingControl.currentPage++;
        LoadPageResults();
    });

    $("body").on("click", "#pagePrevious", function () {
        pagingControl.currentPage--;
        if (pagingControl.currentPage <= 0) pagingControl.currentPage = 1;
        LoadPageResults();
    });

    $("body").on("change", "#pageItemCount", function () {
        pagingControl.itemCount = $(this).val();
        LoadPageResults();
    });
})

function LoadPageResults() {
    $("#employeeList").load("/Home/GetNextPage?page=" + pagingControl.currentPage + "&itemCount=" + pagingControl.itemCount, function () { EnableDisableControls(); });
}

function EnableDisableControls() {
    if (pagingControl.currentPage == 1) {
        $("#pagePrevious").addClass("linkDisabled")
    } else {
        $("#pagePrevious").removeClass("linkDisabled")
    }
}