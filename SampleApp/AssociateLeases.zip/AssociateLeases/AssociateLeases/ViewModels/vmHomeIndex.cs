﻿using SharedModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssociateLeases.ViewModels
{
    public class vmHomeIndex
    {
        public List<jsonEligibility> employerEligibilityList { get; set; }
    }
}