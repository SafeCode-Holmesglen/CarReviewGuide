﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(AssociateLeases.Startup))]
namespace AssociateLeases
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
